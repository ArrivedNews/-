# ARRIVED | The eHailing Network News
## Website Deployment Guide for GitHub Pages

---

### WHAT IS IN THIS FOLDER

```
arrived-website/
├── index.html        ← The full website (one file)
├── assets/
│   └── logo.png      ← Your ARRIVED logo
└── README.md         ← This guide
```

---

### HOW TO GET THIS LIVE IN 10 MINUTES (FREE)

#### STEP 1 — Create a GitHub account
Go to https://github.com and sign up for a free account.
Use your name or "arrivednews" as your username.

#### STEP 2 — Create a new repository
- Click the green "New" button on your GitHub dashboard
- Name it exactly: **arrivednews.github.io**
- Set it to **Public**
- Click "Create repository"

#### STEP 3 — Upload your files
- Click "uploading an existing file"
- Drag and drop BOTH files: index.html AND the assets folder with logo.png
- Scroll down, click "Commit changes"

#### STEP 4 — Enable GitHub Pages
- Go to your repository Settings
- Click "Pages" in the left sidebar
- Under "Source" select "Deploy from a branch"
- Select "main" branch, click Save

#### STEP 5 — Your website is LIVE
Within 2 minutes your website will be live at:
**https://arrivednews.github.io**

That is your free, professional website. No monthly fees. Ever.

---

### OPTIONAL: GET A CUSTOM DOMAIN

If you want www.arrivednews.africa or www.arrivednews.com:

1. Buy the domain from Namecheap.com (approximately R150-R250/year)
2. In your GitHub Pages settings, add your custom domain
3. GitHub will give you DNS settings to add at Namecheap
4. Within 24 hours your site loads at your custom domain

---

### HOW TO UPDATE THE WEBSITE

To add new stories or update content:
1. Open index.html in any text editor (Notepad works)
2. Find the section you want to update
3. Make your changes
4. Go to GitHub, click on index.html, click the pencil icon, paste new content
5. Click "Commit changes" and your site updates within 1 minute

---

### CONTACT
arrivednews@gmail.com
WhatsApp: https://whatsapp.com/channel/0029Vb4BAzV2P59pW5mWxB3G
